import static java.lang.System.*;
import java.util.Scanner;

public class ParsePrefixExpression
{
  public static void main(String[] args) {
    // ...

  }

  // ...

}

