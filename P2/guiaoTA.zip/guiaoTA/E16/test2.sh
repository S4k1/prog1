#!/bin/bash
java -ea MainTrain 10 100 4 2 5 7 -2 -11 -1
