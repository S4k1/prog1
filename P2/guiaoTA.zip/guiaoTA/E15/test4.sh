#!/bin/bash

java -ea P1 1 2 out out out
