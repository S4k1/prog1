#!/bin/bash

java -ea P1 1 1 1 2 2 3 4 4
