#!/bin/bash

java -ea P1 2 5 5 max 5 5 4 max min show clear 1
