#!/bin/bash

java -ea P1 1 max min a
