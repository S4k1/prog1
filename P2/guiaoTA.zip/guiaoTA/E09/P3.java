import static java.lang.System.*;

public class P3 {

  public static void main(String[] args) {

  }


}

